# Setup

```
ansible-galaxy collection install -r requirements.yml -p collections
```
